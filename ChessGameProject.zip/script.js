// HTML Elements
const menu = document.getElementById('menu');
const playOptions = document.getElementById('play-options');
const settings = document.getElementById('settings');
const chessGame = document.getElementById('chess-game');

// Buttons
const playBtn = document.getElementById('play-btn');
const settingsBtn = document.getElementById('settings-btn');
const backBtnSettings = document.getElementById('back-btn-settings');
const backBtnPlay = document.getElementById('back-btn-play');
const backBtnGame = document.getElementById('back-btn-game');
const offlineBtn = document.getElementById('offline-btn');
const aiBtn = document.getElementById('ai-btn');
const onlineBtn = document.getElementById('online-btn');
const friendsBtn = document.getElementById('friends-btn');

// Game Elements
const board = document.getElementById('chess-board');
const status = document.getElementById('status');

// Game Logic (Basic Setup)
const chess = new Chess();
const PIECES = {
  p: '♟', r: '♜', n: '♞', b: '♝', q: '♛', k: '♚',
  P: '♙', R: '♖', N: '♘', B: '♗', Q: '♕', K: '♔',
};

function createBoard() {
  board.innerHTML = '';
  const squares = chess.board();

  for (let row = 0; row < 8; row++) {
    for (let col = 0; col < 8; col++) {
      const squareDiv = document.createElement('div');
      squareDiv.classList.add('square', (row + col) % 2 === 0 ? 'light' : 'dark');

      const piece = squares[row][col];
      if (piece) {
        const pieceDiv = document.createElement('div');
        pieceDiv.textContent = PIECES[piece.type];
        pieceDiv.classList.add('piece');
        pieceDiv.dataset.position = `${col},${row}`;
        squareDiv.appendChild(pieceDiv);
      }

      board.appendChild(squareDiv);
    }
  }
}

// Navigation Logic
playBtn.addEventListener('click', () => {
  menu.classList.add('hidden');
  playOptions.classList.remove('hidden');
});

settingsBtn.addEventListener('click', () => {
  menu.classList.add('hidden');
  settings.classList.remove('hidden');
});

backBtnSettings.addEventListener('click', () => {
  settings.classList.add('hidden');
  menu.classList.remove('hidden');
});

backBtnPlay.addEventListener('click', () => {
  playOptions.classList.add('hidden');
  menu.classList.remove('hidden');
});

backBtnGame.addEventListener('click', () => {
  chessGame.classList.add('hidden');
  menu.classList.remove('hidden');
});

offlineBtn.addEventListener('click', () => {
  playOptions.classList.add('hidden');
  chessGame.classList.remove('hidden');
  createBoard();
});

aiBtn.addEventListener('click', () => {
  playOptions.classList.add('hidden');
  chessGame.classList.remove('hidden');
  startAIGame();
});

// Start AI Mode
function startAIGame() {
  createBoard();
  updateStatus();

  board.addEventListener('click', (e) => {
    const target = e.target;

    if (target.classList.contains('piece') || target.classList.contains('square')) {
      playerMove(target.dataset.position);
    }
  });
}

// Player Move
function playerMove(position) {
  const [col, row] = position.split(',').map(Number);
  const algebraic = `${String.fromCharCode(97 + col)}${8 - row}`;
  const moves = chess.moves({ square: algebraic });

  if (moves.length > 0) {
    const move = prompt(`Your available moves: ${moves.join(', ')}
Enter your move:`);
    if (chess.move(move)) {
      createBoard();
      updateStatus();

      if (!chess.game_over()) {
        setTimeout(aiMove, 500);
      }
    }
  } else {
    alert('Invalid move!');
  }
}

// AI Move
function aiMove() {
  const moves = chess.moves();
  const randomMove = moves[Math.floor(Math.random() * moves.length)];
  chess.move(randomMove);

  createBoard();
  updateStatus();

  if (chess.game_over()) {
    if (chess.in_checkmate()) {
      alert('AI wins! Better luck next time.');
    } else {
      alert('Draw! No winner this time.');
    }
  }
}

// Update Status
function updateStatus() {
  if (chess.in_checkmate()) {
    status.textContent = 'Checkmate! Game Over!';
  } else if (chess.in_stalemate()) {
    status.textContent = 'Stalemate! Game Over!';
  } else if (chess.in_check()) {
    status.textContent = 'Check!';
  } else {
    status.textContent = `${chess.turn() === 'w' ? 'White' : 'Black'} to move.`;
  }
}

// Initialize Game
createBoard();
